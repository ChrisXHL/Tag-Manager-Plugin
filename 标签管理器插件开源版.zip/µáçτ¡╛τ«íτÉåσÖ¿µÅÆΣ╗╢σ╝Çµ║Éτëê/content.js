// 监听来自背景脚本的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getPageContent") {
        // 获取页面内容
        const pageContent = document.body.innerText;
        // 将页面内容发送回背景脚本
        sendResponse({ content: pageContent });
    } else if (request.action === "getPageMetadata") {
        // 获取并发送页面元数据
        sendResponse(getPageMetadata());
    }
    // 移除了 "showSidebar" 的处理
});

// 获取页面的元数据
function getPageMetadata() {
    const metadata = {
        title: document.title,
        description: document.querySelector('meta[name="description"]')?.content || '',
        keywords: document.querySelector('meta[name="keywords"]')?.content || '',
        h1: document.querySelector('h1')?.innerText || ''
    };
    return metadata;
}

// 移除了 createSidebar、generatePathHtml、closeSidebar 和 closeSidebarOnOutsideClick 函数

console.log("内容脚本已加载");
