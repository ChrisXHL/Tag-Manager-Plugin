// 创建搜索挂件
function createSearchWidget() {
  const widget = document.createElement('div');
  widget.id = 'ai-bookmark-widget';
  widget.innerHTML = `
    <h3>相关书签</h3>
    <div id="ai-bookmark-content"></div>
  `;
  document.body.appendChild(widget);
  return widget;
}

// 获取搜索词
function getSearchQuery() {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get('q');
}

// 检查搜索词是否匹配书签标签
async function checkBookmarkMatch(searchQuery) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ action: "checkBookmarkMatch", searchQuery: searchQuery }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('检查书签匹配时出错:', chrome.runtime.lastError);
        reject(chrome.runtime.lastError);
      } else {
        console.log('收到书签匹配结果:', response);
        resolve(response);
      }
    });
  });
}

// 更新挂件内容
function updateWidgetContent(content) {
  const widgetContent = document.getElementById('ai-bookmark-content');
  if (widgetContent) {
    widgetContent.innerHTML = content;
    console.log('挂件内容已更新:', content);
  } else {
    console.error('未找到挂件内容元素');
  }
}

// 生成书签列表HTML
function generateBookmarkListHtml(bookmarks) {
  if (bookmarks.length === 0) {
    return '<p>没有找到相关书签。</p>';
  }
  return `
    <ul>
      ${bookmarks.map(bookmark => `
        <li>
          <a href="${bookmark.url}" target="_blank">${bookmark.title}</a>
        </li>
      `).join('')}
    </ul>
  `;
}

// 主函数
async function main() {
  try {
    const widget = createSearchWidget();
    const searchQuery = getSearchQuery();

    if (searchQuery) {
      updateWidgetContent('<p>正在检查相关书签...</p>');
      const matchResult = await checkBookmarkMatch(searchQuery);

      if (matchResult.matched && matchResult.bookmarks.length > 0) {
        const bookmarkListHtml = generateBookmarkListHtml(matchResult.bookmarks);
        updateWidgetContent(`
          </edit>
            ${bookmarkListHtml}
          </div>
        `);
      } else {
        updateWidgetContent(`
          <h4>搜索词：${searchQuery}</h4>
          <p>未找到相关书签。</p>
        `);
      }
    } else {
      updateWidgetContent('<p>无法获取搜索词。</p>');
    }
  } catch (error) {
    console.error('主函数执行出错:', error);
    updateWidgetContent('<p>发生错误，请稍后再试。</p>');
  }
}

// 执行主函数
main();