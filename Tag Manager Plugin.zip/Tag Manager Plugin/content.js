// Listen for messages from the background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getPageContent") {
        // Get the page content
        const pageContent = document.body.innerText;
        // Send the page content back to the background script
        sendResponse({ content: pageContent });
    } else if (request.action === "getPageMetadata") {
        // Get and send the page metadata
        sendResponse(getPageMetadata());
    }
    // Removed handling for "showSidebar"
});

// Get the page metadata
function getPageMetadata() {
    const metadata = {
        title: document.title,
        description: document.querySelector('meta[name="description"]')?.content || '',
        keywords: document.querySelector('meta[name="keywords"]')?.content || '',
        h1: document.querySelector('h1')?.innerText || ''
    };
    return metadata;
}

// Removed createSidebar, generatePathHtml, closeSidebar, and closeSidebarOnOutsideClick functions

console.log("Content script loaded");
