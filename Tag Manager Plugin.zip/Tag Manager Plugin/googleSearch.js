// Create search widget
function createSearchWidget() {
  const widget = document.createElement('div');
  widget.id = 'ai-bookmark-widget';
  widget.innerHTML = `
    <h3>Related Bookmarks</h3>
    <div id="ai-bookmark-content"></div>
  `;
  document.body.appendChild(widget);
  return widget;
}

// Get search query
function getSearchQuery() {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get('q');
}

// Check if search query matches bookmark tags
async function checkBookmarkMatch(searchQuery) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ action: "checkBookmarkMatch", searchQuery: searchQuery }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('Error checking bookmark match:', chrome.runtime.lastError);
        reject(chrome.runtime.lastError);
      } else {
        console.log('Received bookmark match results:', response);
        resolve(response);
      }
    });
  });
}

// Update widget content
function updateWidgetContent(content) {
  const widgetContent = document.getElementById('ai-bookmark-content');
  if (widgetContent) {
    widgetContent.innerHTML = content;
    console.log('Widget content updated:', content);
  } else {
    console.error('Widget content element not found');
  }
}

// Generate bookmark list HTML
function generateBookmarkListHtml(bookmarks) {
  if (bookmarks.length === 0) {
    return '<p>No related bookmarks found.</p>';
  }
  return `
    <ul>
      ${bookmarks.map(bookmark => `
        <li>
          <a href="${bookmark.url}" target="_blank">${bookmark.title}</a>
        </li>
      `).join('')}
    </ul>
  `;
}

// Main function
async function main() {
  try {
    const widget = createSearchWidget();
    const searchQuery = getSearchQuery();

    if (searchQuery) {
      updateWidgetContent('<p>Checking related bookmarks...</p>');
      const matchResult = await checkBookmarkMatch(searchQuery);

      if (matchResult.matched && matchResult.bookmarks.length > 0) {
        const bookmarkListHtml = generateBookmarkListHtml(matchResult.bookmarks);
        updateWidgetContent(`
          ${bookmarkListHtml}
          </div>
        `);
      } else {
        updateWidgetContent(`
          <h4>Search query: ${searchQuery}</h4>
          <p>No related bookmarks found.</p>
        `);
      }
    } else {
      updateWidgetContent('<p>Unable to get search query.</p>');
    }
  } catch (error) {
    console.error('Error executing main function:', error);
    updateWidgetContent('<p>An error occurred. Please try again later.</p>');
  }
}

// Execute main function
main();