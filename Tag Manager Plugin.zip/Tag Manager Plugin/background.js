// Remove import statements, use fetch API instead

// Define API configuration for Zhipu AI
const API_CONFIG = {
    API_KEY: "apikey", // Replace with your actual API key
    API_URL: "https://open.bigmodel.cn/api/paas/v4/chat/completions", // Zhipu AI API URL
    MODEL: "glm-4-flash" // Model used by Zhipu AI
};

// Get information of the current active tab
async function getCurrentTab() {
    // Query the active tab in the current window
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    // Return the information of the retrieved tab
    return tab;
}

// Fetch page content
async function fetchPageContent(tabId) {
    // Return a new Promise object
    return new Promise((resolve, reject) => {
        // Send a message to the specified tab to get page content
        chrome.tabs.sendMessage(tabId, { action: "getPageContent" }, (response) => {
            // If an error occurs, reject the Promise and pass the error message
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
            } else if (response && response.content) {
                // If content is successfully retrieved, log the content length and resolve the Promise
                console.log("Page content retrieved, length:", response.content.length);
                resolve(response.content);
            } else {
                // If content cannot be retrieved, reject the Promise and pass the error message
                reject(new Error("Unable to retrieve page content"));
            }
        });
    });
}

// Fetch page metadata
async function fetchPageMetadata(tabId) {
    // Return a new Promise object
    return new Promise((resolve, reject) => {
        // Send a message to the specified tab to get page metadata
        chrome.tabs.sendMessage(tabId, { action: "getPageMetadata" }, (response) => {
            // If an error occurs, reject the Promise and pass the error message
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
            } else if (response) {
                // If metadata is successfully retrieved, log the metadata and resolve the Promise
                console.log("Page metadata retrieved:", response);
                resolve(response);
            } else {
                // If metadata cannot be retrieved, reject the Promise and pass the error message
                reject(new Error("Unable to retrieve page metadata"));
            }
        });
    });
}

// Classify content using Zhipu AI's API
async function classifyContent(prompt, metadata) {
    try {
        // Use fetch API to send a request to Zhipu AI's API
        const response = await fetch(API_CONFIG.API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${API_CONFIG.API_KEY}`
            },
            body: JSON.stringify({
                model: API_CONFIG.MODEL,
                messages: [
                    { role: 'system', content: "## Your Identity and Task\nYou are a web page classification expert. Please classify the following web page content, considering the relationship between the content and the platform of the web link, and return a hierarchical classification structure, with a maximum of one level.\n\n## Rules\n1. Only reply with the most suitable complete folder path.\n2. Do not add any other text.\n\n## Notes\n- Ensure understanding of the association between web content and platform relationships, making accurate judgments based on the theme and source of the content.\n- Ensure clarity of hierarchical classification, with each content assigned to a maximum of two levels.\n- Do not provide any text or explanation other than the classification path in your response.\n\n## Processing Details\n- Check the main content theme of the web page.\n- Determine the best classification related to the web content and platform.\n- Output a hierarchical classification structure without extra text.\n\n## Output Example\nTechnology > Artificial Intelligence" },
                    { role: 'user', content: prompt }
                ]
            })
        });

        // Check if the response is successful
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        // Parse the JSON data from the response
        const result = await response.json();
        // Return the response content from Zhipu AI
        return result.choices[0].message.content.trim();
    } catch (error) {
        // Log the error message and throw the error
        console.error('Content classification failed:', error);
        throw error;
    }
}

// Listen for messages from popup and content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // Log the received message
    console.log("Background script received message:", request);
    // Perform different actions based on the action property of the message
    if (request.action === "classifyBookmark") {
        // Call the classifyBookmark function to classify the bookmark
        classifyBookmark(request.bookmarkId, request.bookmarksBarId)
            .then(result => {
                // Log the classification result and send the response
                console.log("Classification completed, result:", result);
                sendResponse({ success: true, category: result.category, bookmarkInfo: result.bookmarkInfo });
            })
            .catch(error => {
                // Log the error message and send the error response
                console.error("Bookmark classification failed:", error);
                sendResponse({ success: false, error: error.message });
            });
        return true; // Keep the message channel open
    } else if (request.action === "checkBookmarkMatch") {
        // Call the checkBookmarkMatch function to check bookmark match
        checkBookmarkMatch(request.searchQuery)
            .then(result => sendResponse(result))
            .catch(error => {
                // Log the error message and send the error response
                console.error("Bookmark match check failed:", error);
                sendResponse({ matched: false, error: error.message });
            });
        return true; // Keep the message channel open
    } else if (request.action === "processMatchedBookmarks") {
        // Call the processMatchedBookmarks function to process matched bookmarks
        processMatchedBookmarks(request.matchedBookmarks, request.searchQuery)
            .then(result => sendResponse(result))
            .catch(error => {
                // Log the error message and send the error response
                console.error("Processing matched bookmarks failed:", error);
                sendResponse({ content: "Error processing bookmarks, please try again later." });
            });
        return true; // Keep the message channel open
    }
});

// Classify bookmark
async function classifyBookmark(bookmarkId, bookmarksBarId) {
    // Log the start of bookmark classification
    console.log("Starting bookmark classification:", bookmarkId);
    try {
        // Get the bookmark information for the specified ID
        const [bookmark] = await chrome.bookmarks.get(bookmarkId);
        // Log the retrieved bookmark information
        console.log("Bookmark information retrieved:", bookmark);
        // Get information of the current active tab
        const tab = await getCurrentTab();
        // Log the current tab information
        console.log("Current tab information:", tab);
        // Fetch page content
        const content = await fetchPageContent(tab.id);
        // Log the retrieved page content
        console.log("Page content retrieved");
        // Fetch page metadata
        const metadata = await fetchPageMetadata(tab.id);
        // Log the retrieved page metadata
        console.log("Page metadata retrieved:", metadata);
        
        // Get the existing bookmark folder structure
        const existingFolders = await getExistingFolders(bookmarksBarId);
        // Log the existing bookmark folder structure
        console.log("Existing bookmark folders:", existingFolders);
        
        // Use AI to determine the most suitable folder
        const bestFolder = await findBestFolder(content, metadata, existingFolders);
        // Log the AI-recommended best folder
        console.log("AI-recommended best folder:", bestFolder);

        let category, targetFolderId;
        if (bestFolder) {
            // If a suitable folder is found, set the category and target folder ID
            category = bestFolder.path.join(' > ');
            targetFolderId = bestFolder.id;
        } else {
            // If no suitable folder is found, create a new one
            category = await classifyContent(`
            Page Title: ${metadata.title}
            Page Description: ${metadata.description}
            Keywords: ${metadata.keywords}
            H1 Title: ${metadata.h1}
            URL: ${metadata.url}
            Page Content: ${content.substring(0, 500)}`, metadata);
            // Create a new folder structure
            targetFolderId = await createFolderStructure(bookmarksBarId, category.split(' > '));
        }

        // Move the bookmark to the target folder
        await chrome.bookmarks.move(bookmarkId, {parentId: targetFolderId});
        // Log the completion of bookmark classification
        console.log(`Bookmark classified to "${category}"`);

        // Get the full path of the bookmark
        const bookmarkPath = await getBookmarkPath(bookmarkId);
        
        // Return the classification result and bookmark information
        return {
            category: category,
            bookmarkInfo: {
                title: bookmark.title,
                url: bookmark.url,
                category: category,
                path: bookmarkPath
            }
        };
    } catch (error) {
        // Log the error message and throw the error
        console.error('Error during bookmark classification:', error);
        throw error;
    }
}

// Get the existing bookmark folder structure
async function getExistingFolders(bookmarksBarId) {
    // Get the subtree structure of the bookmarks bar
    const bookmarksTree = await chrome.bookmarks.getSubTree(bookmarksBarId);
    const folders = [];

    // Traverse the bookmark tree to collect folder information
    function traverseTree(node, path = []) {
        if (node.url) return; // Skip non-folder nodes
        const currentPath = [...path, node.title];
        folders.push({ id: node.id, title: node.title, path: currentPath });
        if (node.children) {
            node.children.forEach(child => traverseTree(child, currentPath));
        }
    }

    // Traverse the children of the bookmarks bar
    bookmarksTree[0].children.forEach(child => traverseTree(child));
    // Return the collected folder information
    return folders;
}

// Use AI to find the most suitable folder
async function findBestFolder(content, metadata, existingFolders) {
    // Convert the existing folder structure to a string
    const folderStructure = existingFolders.map(folder => folder.path.join(' > ')).join('\n');
    // Construct the prompt for classification
    const prompt = `
        Page Title: ${metadata.title}
        Page Description: ${metadata.description}
        Keywords: ${metadata.keywords}
        H1 Title: ${metadata.h1}
        URL: ${metadata.url}
        Page Content: ${content.substring(0, 500)}...
        
        ## Existing Folder Structure
        ${folderStructure}`;

    try {
        // Call the classifyContent function for classification
        const classification = await classifyContent(prompt, {});
        // If the classification result is "None", return null
        if (classification === "None") return null;
        // Find the matching folder in the existing folders
        return existingFolders.find(folder => folder.path.join(' > ') === classification) || null;
    } catch (error) {
        // Log the error message and return null
        console.error('Failed to find the best folder:', error);
        return null;
    }
}

// Get the full path of the bookmark
async function getBookmarkPath(bookmarkId) {
    const path = [];
    let currentId = bookmarkId;
    
    // Loop to get the parent nodes of the bookmark, constructing the full path
    while (currentId) {
        const [bookmark] = await chrome.bookmarks.get(currentId);
        if (bookmark.parentId) {
            path.unshift(bookmark.title);
        }
        currentId = bookmark.parentId;
    }
    
    // Return the full path
    return path;
}

// Create folder structure
async function createFolderStructure(parentId, folderNames) {
    let currentParentId = parentId;
    // Iterate over folder names to create folders step by step
    for (const folderName of folderNames) {
        const existingFolders = await chrome.bookmarks.getChildren(currentParentId);
        const existingFolder = existingFolders.find(f => f.title === folderName && !f.url);
        if (existingFolder) {
            // If the folder already exists, update the current parent folder ID
            currentParentId = existingFolder.id;
        } else {
            // If the folder does not exist, create a new folder
            const newFolder = await chrome.bookmarks.create({
                parentId: currentParentId,
                title: folderName
            });
            // Update the current parent folder ID to the newly created folder ID
            currentParentId = newFolder.id;
        }
    }
    // Return the ID of the final created folder
    return currentParentId;
}

// Check if the search query matches bookmark tags
async function checkBookmarkMatch(searchQuery) {
  // Search all bookmarks
  const bookmarks = await chrome.bookmarks.search({});
  // Convert the search query to lowercase and split into keywords array
  const keywords = searchQuery.toLowerCase().split(/\s+/);
  
  // Filter bookmarks, checking if each bookmark's title and URL contain all keywords
  const matchedBookmarks = bookmarks.filter(bookmark => {
    const title = bookmark.title.toLowerCase();
    const url = (bookmark.url || '').toLowerCase();
    return keywords.every(keyword => 
      title.includes(keyword) || url.includes(keyword)
    );
  });

  // Return the match result and matched bookmark information
  return { 
    matched: matchedBookmarks.length > 0, 
    bookmarks: matchedBookmarks.map(b => ({
      id: b.id,
      title: b.title,
      url: b.url
    }))
  };
}
