document.getElementById("classifyButton").addEventListener("click", async () => {
    console.log("Classification button clicked"); // Classification button clicked
    updateFeedback("Processing...", true); // Processing...

    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        console.log("Current tab info:", tab); // Current tab info
        
        const bookmarksBarId = await getBookmarksBarId();
        
        const existingBookmarks = await chrome.bookmarks.search({url: tab.url});
        let bookmarkId;
        
        if (existingBookmarks.length > 0) {
            bookmarkId = existingBookmarks[0].id;
            console.log("Existing bookmark:", bookmarkId); // Existing bookmark
        } else {
            const newBookmark = await createBookmark(tab, bookmarksBarId);
            bookmarkId = newBookmark;
            console.log("Newly created bookmark:", bookmarkId); // Newly created bookmark
        }
        
        chrome.runtime.sendMessage({ action: "classifyBookmark", bookmarkId: bookmarkId, bookmarksBarId: bookmarksBarId }, async (response) => {
            console.log("Received background script response:", response); // Received background script response
            if (response && response.success) {
                updateFeedback(`Bookmark has been ${existingBookmarks.length > 0 ? 'updated' : 'created'} and classified as: ${response.category}`);
            } else {
                updateFeedback("Bookmark classification failed, please try again. Error: " + (response ? response.error : "Unknown error"));
            }
        });
    } catch (error) {
        console.error("Error processing bookmark:", error); // Error processing bookmark
        updateFeedback("Error processing bookmark, please try again. Error: " + error.message);
    }
});

async function getBookmarksBarId() {
    const tree = await chrome.bookmarks.getTree();
    return tree[0].children[0].id;
}

async function createBookmark(tab, parentId) {
    try {
        const bookmark = await chrome.bookmarks.create({ 
            parentId: parentId,
            title: tab.title, 
            url: tab.url 
        });
        return bookmark.id;
    } catch (error) {
        console.error("Failed to create bookmark:", error); // Failed to create bookmark
        throw error;
    }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log("Received background script message:", request); // Received background script message
    if (request.action === "promptNewCategory") {
        const userResponse = confirm(`Category "${request.classification}" does not exist, would you like to create a new category?`);
        if (userResponse) {
            const newCategory = prompt("Please enter new category name:");
            sendResponse({ newCategory: newCategory });
        } else {
            sendResponse({ newCategory: null });
        }
    }
    return true;
});

function updateFeedback(message, show = true) {
    const feedbackElement = document.getElementById("feedback");
    if (feedbackElement) {
        feedbackElement.textContent = message;
        feedbackElement.style.display = show ? "block" : "none";
    } else {
        console.error("Feedback element not found"); // Feedback element not found
    }
}