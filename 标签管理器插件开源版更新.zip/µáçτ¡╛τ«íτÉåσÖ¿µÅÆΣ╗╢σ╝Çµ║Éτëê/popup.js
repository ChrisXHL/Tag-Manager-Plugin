document.getElementById("classifyButton").addEventListener("click", async () => {
    console.log("分类按钮被点击");
    updateFeedback("正在处理...", true);

    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        console.log("当前标签信息:", tab);
        
        const bookmarksBarId = await getBookmarksBarId();
        
        const existingBookmarks = await chrome.bookmarks.search({url: tab.url});
        let bookmarkId;
        
        if (existingBookmarks.length > 0) {
            bookmarkId = existingBookmarks[0].id;
            console.log("已存在的书签:", bookmarkId);
        } else {
            const newBookmark = await createBookmark(tab, bookmarksBarId);
            bookmarkId = newBookmark;
            console.log("新创建的书签:", bookmarkId);
        }
        
        chrome.runtime.sendMessage({ action: "classifyBookmark", bookmarkId: bookmarkId, bookmarksBarId: bookmarksBarId }, async (response) => {
            console.log("收到背景脚本的响应:", response);
            if (response && response.success) {
                updateFeedback(`书签已${existingBookmarks.length > 0 ? '更新' : '创建'}并分类为: ${response.category}`);
                // 删除显示侧边栏的代码
            } else {
                updateFeedback("书签分类失败，请重试。错误信息：" + (response ? response.error : "未知错误"));
            }
        });
    } catch (error) {
        console.error("处理书签时出错:", error);
        updateFeedback("处理书签时出错，请重试。错误信息：" + error.message);
    }
});

async function getBookmarksBarId() {
    const tree = await chrome.bookmarks.getTree();
    return tree[0].children[0].id;
}

async function createBookmark(tab, parentId) {
    try {
        const bookmark = await chrome.bookmarks.create({ 
            parentId: parentId,
            title: tab.title, 
            url: tab.url 
        });
        return bookmark.id;
    } catch (error) {
        console.error("创建书签失败:", error);
        throw error;
    }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log("收到背景脚本消息:", request);
    if (request.action === "promptNewCategory") {
        const userResponse = confirm(`分类 "${request.classification}" 不在已有标签中，是否创建新分类？`);
        if (userResponse) {
            const newCategory = prompt("请输入新分类名称:");
            sendResponse({ newCategory: newCategory });
        } else {
            sendResponse({ newCategory: null });
        }
    }
    return true;
});

function updateFeedback(message, show = true) {
    const feedbackElement = document.getElementById("feedback");
    if (feedbackElement) {
        feedbackElement.textContent = message;
        feedbackElement.style.display = show ? "block" : "none";
    } else {
        console.error("未找到 feedback 元素");
    }
}