// 创建搜索挂件
function createSearchWidget() {
  const widget = document.createElement('div'); // 创建一个新的 div 元素作为挂件
  widget.id = 'ai-bookmark-widget'; // 设置挂件的 id
  widget.innerHTML = `
    <h3>相关书签</h3>
    <div id="ai-bookmark-content"></div>
  `; // 设置挂件的 HTML 内容
  document.body.appendChild(widget); // 将挂件添加到文档的 body 中
  return widget; // 返回创建的挂件
}

// 获取搜索词
function getSearchQuery() {
  const urlParams = new URLSearchParams(window.location.search); // 获取 URL 中的查询参数
  return urlParams.get('q'); // 返回查询参数中的 'q' 值，即搜索词
}

// 检查搜索词是否匹配书签标签
async function checkBookmarkMatch(searchQuery) {
  return new Promise((resolve, reject) => {
    // 发送消息到后台脚本以检查书签匹配
    chrome.runtime.sendMessage({ action: "checkBookmarkMatch", searchQuery: searchQuery }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('检查书签匹配时出错:', chrome.runtime.lastError); // 打印错误信息
        reject(chrome.runtime.lastError); // 拒绝 Promise 并传递错误信息
      } else {
        // 过滤掉没有 URL 的书签（即文件夹）
        const filteredBookmarks = response.bookmarks.filter(bookmark => bookmark.url);
        console.log('收到书签匹配结果:', filteredBookmarks); // 打印过滤后的书签
        resolve({ matched: filteredBookmarks.length > 0, bookmarks: filteredBookmarks }); // 解析 Promise 并传递结果
      }
    });
  });
}

// 更新挂件内容
function updateWidgetContent(content) {
  const widgetContent = document.getElementById('ai-bookmark-content'); // 获取挂件内容的元素
  if (widgetContent) {
    widgetContent.innerHTML = content; // 更新挂件内容
    console.log('挂件内容已更新:', content); // 打印更新后的内容
  } else {
    console.error('未找到挂件内容元素'); // 打印错误信息
  }
}

// 生成书签列表HTML
function generateBookmarkListHtml(bookmarks) {
  if (bookmarks.length === 0) {
    return '<p>没有找到相关书签。</p>'; // 如果没有书签，返回提示信息
  }
  return `
    <ul>
      ${bookmarks.map(bookmark => `
        <li>
          <a href="${bookmark.url}" target="_blank">${bookmark.title}</a>
        </li>
      `).join('')}
    </ul>
  `; // 生成书签列表的 HTML
}

// 主函数
async function main() {
  try {
    const widget = createSearchWidget(); // 创建搜索挂件
    const searchQuery = getSearchQuery(); // 获取搜索词

    if (searchQuery) {
      updateWidgetContent('<p>正在检查相关书签...</p>'); // 更新挂件内容为检查中
      const matchResult = await checkBookmarkMatch(searchQuery); // 检查书签匹配

      if (matchResult.matched && matchResult.bookmarks.length > 0) {
        const bookmarkListHtml = generateBookmarkListHtml(matchResult.bookmarks); // 生成书签列表 HTML
        updateWidgetContent(`
          <h4>搜索词：${searchQuery}</h4>
          ${bookmarkListHtml}
        `); // 更新挂件内容为书签列表
      } else {
        updateWidgetContent(`
          <h4>搜索词：${searchQuery}</h4>
          <p>未找到相关书签。</p>
        `); // 更新挂件内容为未找到书签
      }
    } else {
      updateWidgetContent('<p>无法获取搜索词。</p>'); // 更新挂件内容为无法获取搜索词
    }
  } catch (error) {
    console.error('主函数执行出错:', error); // 打印错误信息
    updateWidgetContent('<p>发生错误，请稍后再试。</p>'); // 更新挂件内容为错误信息
  }
}

// 执行主函数
main(); // 调用主函数