// 移除 import 语句，改用 fetch API

// 定义智谱AI的API配置
const API_CONFIG = {
    API_KEY: "apikey", // 替换为你的实际API密钥
    API_URL: "https://open.bigmodel.cn/api/paas/v4/chat/completions", // 智谱AI的API地址
    MODEL: "glm-4-flash" // 使用智谱AI的模型
};

// 获取当前活动标签的信息
async function getCurrentTab() {
    // 查询当前窗口中活动的标签页
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    // 返回获取到的标签页信息
    return tab;
}

// 获取页面内容
async function fetchPageContent(tabId) {
    // 返回一个新的 Promise 对象
    return new Promise((resolve, reject) => {
        // 向指定的标签页发送消息以获取页面内容
        chrome.tabs.sendMessage(tabId, { action: "getPageContent" }, (response) => {
            // 如果发生错误，拒绝 Promise 并传递错误信息
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
            } else if (response && response.content) {
                // 如果成功获取到内容，打印内容长度并解析 Promise
                console.log("获取到页面内容，长度:", response.content.length);
                resolve(response.content);
            } else {
                // 如果未能获取内容，拒绝 Promise 并传递错误信息
                reject(new Error("无法获取页面内容"));
            }
        });
    });
}

// 获取页面元数据
async function fetchPageMetadata(tabId) {
    // 返回一个新的 Promise 对象
    return new Promise((resolve, reject) => {
        // 向指定的标签页发送消息以获取页面元数据
        chrome.tabs.sendMessage(tabId, { action: "getPageMetadata" }, (response) => {
            // 如果发生错误，拒绝 Promise 并传递错误信息
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
            } else if (response) {
                // 如果成功获取到元数据，打印元数据并解析 Promise
                console.log("获取到页面元数据:", response);
                resolve(response);
            } else {
                // 如果未能获取元数据，拒绝 Promise 并传递错误信息
                reject(new Error("无法获取页面元数据"));
            }
        });
    });
}

// 使用智谱AI的API进行分类
async function classifyContent(prompt, metadata) {
    try {
        // 使用 fetch API 向智谱AI的API发送请求
        const response = await fetch(API_CONFIG.API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${API_CONFIG.API_KEY}`
            },
            body: JSON.stringify({
                model: API_CONFIG.MODEL,
                messages: [
                    { role: 'system', content: "## 你的身份和任务\n你是一位网页分类专家，请对以下网页内容进行分类，综合考虑内容和网页链接的平台关系，返回一个层级分类结构，最多一个层级。\n\n## 规则\n1. 只回复最合适的完整文件夹路径。\n2. 不要添加任何其他文字。\n\n## 注意事项\n- 确保理解网页内容和平台关系之间的关联，通过内容的主题和来源来进行准确判断。\n- 保证层级结构分类的清晰性，每个内容最多被分配到两层结构中。\n- 回答时不提供除了分类路径之外的其他文字或解释。\n\n## 处理细节\n- 检查网页的主要内容主题。\n- 确定与网页内容和平台相关的最佳分类。\n- 输出不含多余文字的层级分类结构。\n\n## 输出案例\n技术 > 人工智能" },
                    { role: 'user', content: prompt }
                ]
            })
        });

        // 检查响应是否成功
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        // 解析响应的JSON数据
        const result = await response.json();
        // 返回智谱AI的响应内容
        return result.choices[0].message.content.trim();
    } catch (error) {
        // 打印错误信息并抛出错误
        console.error('内容分类失败:', error);
        throw error;
    }
}

// 监听来自popup和content script的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // 打印接收到的消息
    console.log("背景脚本收到消息:", request);
    // 根据消息的 action 属性执行不同的操作
    if (request.action === "classifyBookmark") {
        // 调用 classifyBookmark 函数进行书签分类
        classifyBookmark(request.bookmarkId, request.bookmarksBarId)
            .then(result => {
                // 打印分类结果并发送响应
                console.log("分类完成，结果:", result);
                sendResponse({ success: true, category: result.category, bookmarkInfo: result.bookmarkInfo });
            })
            .catch(error => {
                // 打印错误信息并发送错误响应
                console.error("分类书签失败:", error);
                sendResponse({ success: false, error: error.message });
            });
        return true; // 保持消息通道开放
    } else if (request.action === "checkBookmarkMatch") {
        // 调用 checkBookmarkMatch 函数检查书签匹配
        checkBookmarkMatch(request.searchQuery)
            .then(result => sendResponse(result))
            .catch(error => {
                // 打印错误信息并发送错误响应
                console.error("检查书签匹配失败:", error);
                sendResponse({ matched: false, error: error.message });
            });
        return true; // 保持消息通道开放
    } else if (request.action === "processMatchedBookmarks") {
        // 调用 processMatchedBookmarks 函数处理匹配的书签
        processMatchedBookmarks(request.matchedBookmarks, request.searchQuery)
            .then(result => sendResponse(result))
            .catch(error => {
                // 打印错误信息并发送错误响应
                console.error("处理匹配书签失败:", error);
                sendResponse({ content: "处理书签时出错，请稍后再试。" });
            });
        return true; // 保持消息通道开放
    }
});

// 分类书签
async function classifyBookmark(bookmarkId, bookmarksBarId) {
    // 打印开始分类书签的日志
    console.log("开始分类书签:", bookmarkId);
    try {
        // 获取指定 ID 的书签信息
        const [bookmark] = await chrome.bookmarks.get(bookmarkId);
        // 打印获取到的书签信息
        console.log("获取到书签信息:", bookmark);
        // 获取当前活动标签的信息
        const tab = await getCurrentTab();
        // 打印当前标签信息
        console.log("当前标签信息:", tab);
        // 获取页面内容
        const content = await fetchPageContent(tab.id);
        // 打印获取到的页面内容
        console.log("获取到页面内容");
        // 获取页面元数据
        const metadata = await fetchPageMetadata(tab.id);
        // 打印获取到的页面元数据
        console.log("获取到页面元数据:", metadata);
        
        // 获取现有的书签文件夹结构
        const existingFolders = await getExistingFolders(bookmarksBarId);
        // 打印现有书签文件夹结构
        console.log("现有书签文件夹:", existingFolders);
        
        // 使用AI判断最合适的文件夹
        const bestFolder = await findBestFolder(content, metadata, existingFolders);
        // 打印AI推荐的最佳文件夹
        console.log("AI推荐的最佳文件夹:", bestFolder);

        let category, targetFolderId;
        if (bestFolder) {
            // 如果找到合适的文件夹，设置分类和目标文件夹ID
            category = bestFolder.path.join(' > ');
            targetFolderId = bestFolder.id;
        } else {
            // 如果没有合适的文件夹，创建新的
            category = await classifyContent(`
            网页标题：${metadata.title}
            网页描述：${metadata.description}
            关键词：${metadata.keywords}
            H1标题：${metadata.h1}
            链接：${metadata.url}
            页面内容：${content.substring(0, 500)}`, metadata);
            // 创建新的文件夹结构
            targetFolderId = await createFolderStructure(bookmarksBarId, category.split(' > '));
        }

        // 移动书签到目标文件夹
        await chrome.bookmarks.move(bookmarkId, {parentId: targetFolderId});
        // 打印书签分类完成的日志
        console.log(`书签已分类到 "${category}"`);

        // 获取书签的完整路径
        const bookmarkPath = await getBookmarkPath(bookmarkId);
        
        // 返回分类结果和书签信息
        return {
            category: category,
            bookmarkInfo: {
                title: bookmark.title,
                url: bookmark.url,
                category: category,
                path: bookmarkPath
            }
        };
    } catch (error) {
        // 打印错误信息并抛出错误
        console.error('书签分类过程中出错:', error);
        throw error;
    }
}

// 获取现有的书签文件夹结构
async function getExistingFolders(bookmarksBarId) {
    // 获取书签栏的子树结构
    const bookmarksTree = await chrome.bookmarks.getSubTree(bookmarksBarId);
    const folders = [];

    // 遍历书签树以收集文件夹信息
    function traverseTree(node, path = []) {
        if (node.url) return; // 跳过非文件夹节点
        const currentPath = [...path, node.title];
        folders.push({ id: node.id, title: node.title, path: currentPath });
        if (node.children) {
            node.children.forEach(child => traverseTree(child, currentPath));
        }
    }

    // 遍历书签栏的子节点
    bookmarksTree[0].children.forEach(child => traverseTree(child));
    // 返回收集到的文件夹信息
    return folders;
}

// 使用AI找到最合适的文件夹
async function findBestFolder(content, metadata, existingFolders) {
    // 将现有文件夹结构转换为字符串
    const folderStructure = existingFolders.map(folder => folder.path.join(' > ')).join('\n');
    // 构建用于分类的提示信息
    const prompt = `
        网页标题：${metadata.title}
        网页描述：${metadata.description}
        关键词：${metadata.keywords}
        H1标题：${metadata.h1}
        链接：${metadata.url}
        页面内容：${content.substring(0, 500)}...
        
        ## 现有文件夹结构
        ${folderStructure}`;

    try {
        // 调用 classifyContent 函数进行分类
        const classification = await classifyContent(prompt, {});
        // 如果分类结果为 "None"，返回 null
        if (classification === "None") return null;
        // 在现有文件夹中查找匹配的文件夹
        return existingFolders.find(folder => folder.path.join(' > ') === classification) || null;
    } catch (error) {
        // 打印错误信息并返回 null
        console.error('查找最佳文件夹失败:', error);
        return null;
    }
}

// 获取书签的完整路径
async function getBookmarkPath(bookmarkId) {
    const path = [];
    let currentId = bookmarkId;
    
    // 循环获取书签的父节点，构建完整路径
    while (currentId) {
        const [bookmark] = await chrome.bookmarks.get(currentId);
        if (bookmark.parentId) {
            path.unshift(bookmark.title);
        }
        currentId = bookmark.parentId;
    }
    
    // 返回完整路径
    return path;
}

// 创建文件夹结构
async function createFolderStructure(parentId, folderNames) {
    let currentParentId = parentId;
    // 遍历文件夹名称，逐级创建文件夹
    for (const folderName of folderNames) {
        const existingFolders = await chrome.bookmarks.getChildren(currentParentId);
        const existingFolder = existingFolders.find(f => f.title === folderName && !f.url);
        if (existingFolder) {
            // 如果文件夹已存在，更新当前父文件夹ID
            currentParentId = existingFolder.id;
        } else {
            // 如果文件夹不存在，创建新文件夹
            const newFolder = await chrome.bookmarks.create({
                parentId: currentParentId,
                title: folderName
            });
            // 更新当前父文件夹ID为新创建的文件夹ID
            currentParentId = newFolder.id;
        }
    }
    // 返回最终创建的文件夹ID
    return currentParentId;
}

// 检查搜索词是否匹配书签标签
async function checkBookmarkMatch(searchQuery) {
  // 搜索所有书签
  const bookmarks = await chrome.bookmarks.search({});
  // 将搜索查询转换为小写并分割为关键词数组
  const keywords = searchQuery.toLowerCase().split(/\s+/);
  
  // 过滤书签，检查每个书签的标题和URL是否包含所有关键词
  const matchedBookmarks = bookmarks.filter(bookmark => {
    const title = bookmark.title.toLowerCase();
    const url = (bookmark.url || '').toLowerCase();
    return keywords.every(keyword => 
      title.includes(keyword) || url.includes(keyword)
    );
  });

  // 返回匹配结果和匹配的书签信息
  return { 
    matched: matchedBookmarks.length > 0, 
    bookmarks: matchedBookmarks.map(b => ({
      id: b.id,
      title: b.title,
      url: b.url
    }))
  };
}
